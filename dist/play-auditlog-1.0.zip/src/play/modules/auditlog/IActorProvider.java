package play.modules.auditlog;

public interface IActorProvider {

  String getActor();
}
